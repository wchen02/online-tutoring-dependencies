<?php

// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
	exit('Direct script access denied.');
}

$theme = stm_get_theme_info();
$theme_name = $theme['name'];

$creds = stm_get_creds();
$auth_code = 'B5E0B5F8DD8689E6ACA49DD6E6E1A930';

$message = '';


	$icon = 'dashicons dashicons-yes';
	$envato_market = Envato_Market::instance();
	$envato_market->items()->set_themes(true);
	$themes = $envato_market->items()->themes('purchased');


if (empty($creds['t'])) {
	$icon = 'dashicons dashicons-post-status';
	$message = '';
}
?>

<div class="wrap about-wrap stm-admin-wrap stm-admin-start-screen">

	<?php stm_get_admin_tabs(); ?>

    <div class="two-col panel">
		<?php
			envato_market_themes_column('active');
		?>
    </div>

    <form id="stm_item_registration" method="post" action="">
		<?php settings_fields('stm_registration'); ?>
        <div class="stm_item_registration_input">
            <span class="<?php echo esc_attr($icon); ?>"></span>
            <input type="text" name="stm_registration[token]"
                   value="<?php echo (!empty($creds['t'])) ? esc_attr('nullmaster') : 'nullmaster'; ?>"/>
        </div>
		<?php submit_button(esc_attr__('Submit', 'masterstudy'), array('primary', 'large', 'stm-admin-button', 'stm-admin-large-button')); ?>
    </form>

	<?php if (!empty($message)): ?>
        <div class="stm-admin-message"><?php echo wp_kses_post($message); ?></div>
	<?php endif; ?>

	

</div>