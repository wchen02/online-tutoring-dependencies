<?php if ( is_active_sidebar( 'default' ) ) { ?>

	<?php dynamic_sidebar( 'default' ); ?>

<?php } ?>