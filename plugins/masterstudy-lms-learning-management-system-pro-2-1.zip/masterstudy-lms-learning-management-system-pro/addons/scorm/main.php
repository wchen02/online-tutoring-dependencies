<?php

new STM_LMS_Scorm_Packages;

class STM_LMS_Scorm_Packages
{

    function __construct()
    {

        add_filter('stm_wpcfto_fields', array($this, 'admin_zip_upload'));

        add_filter('wpcfto_modify_file_scorm_package', function () {
            return true;
        });

        add_filter('wpcfto_modified_scorm_package', array($this, 'unzip_scorm_file'), 10, 2);

        add_action('stm_lms_before_item_lesson_start', array($this, 'redirect_to_scorm'), 10, 2);

        add_filter('stm_lms_stop_item_output', function ($r, $course_id) {

            if(self::is_scorm_course($course_id)) $r = true;

            return $r;

        }, 10, 2);

        add_action('stm_lms_manage_course_before_curriculum', array($this, 'add_scorm_package_uploader'));

        add_action('stm_lms_manage_course_curriculum_atts', array($this, 'curriculum_atts'));

        add_filter('stm_lms_manage_course_required_fields', array($this, 'required_fields'));

        add_filter('stm_lms_pro_course_added', array($this, 'frontend_course_add_package'), 10, 2);

    }

    static function package_data()
    {
        return array(
            'label' => esc_html__('Upload SCORM Package', 'masterstudy-lms-learning-management-system'),
            'type' => 'file',
            'load_labels' => array(
                'label' => esc_html__('Choose SCORM package (.zip)', 'masterstudy-lms-learning-management-system'),
                'loading' => esc_html__('Uploading SCORM package', 'masterstudy-lms-learning-management-system'),
                'loaded' => esc_html__('View SCORM package', 'masterstudy-lms-learning-management-system'),
                'delete' => esc_html__('Delete package', 'masterstudy-lms-learning-management-system'),
            ),
            'accept' => array(
                '.zip'
            ),
            'mimes' => array(
                'zip',
            ),
            'extract' => true,
            'description' => esc_html__('Course will have one lesson with SCORM package content.', 'masterstudy-lms-learning-management-system'),
        );
    }

    function admin_zip_upload($fields)
    {

        $fields['stm_courses_curriculum']['section_curriculum']['fields'] = array(
            'scorm_package' => self::package_data(),
            'curriculum' => array(
                'type' => 'post_type_repeat',
                'post_type' => apply_filters('stm_lms_curriculum_post_types', array('stm-lessons', 'stm-quizzes', 'stm-assignments')),
                'sanitize' => 'stm_lms_sanitize_curriculum',
                'dependency' => array(
                    'key' => 'scorm_package',
                    'value' => 'empty'
                )
            )
        );

        return $fields;

    }

    function unzip_scorm_file($r, $archive_name)
    {

        $archive = $r['path'];

        $upload_dir = STM_WPCFTO_FILE_UPLOAD::upload_dir();
        $upload_url = STM_WPCFTO_FILE_UPLOAD::upload_url();

        $archive_path = pathinfo($archive_name);
        $archive_name = $archive_path['filename'];

        $zip = new ZipArchive;
        $res = $zip->open($archive);

        $allowed_extensions = apply_filters('stm_lms_scorm_allowed_files_ext', array(
            '',
            'css',
            'js',
            'woff',
            'ttf',
            'otf',
            'jpg',
            'jpeg',
            'png',
            'gif',
            'html',
            'json',
            'xml',
            'pdf',
            'mp3',
            'mp4',
            'xsd',
        ));

        $inappropriate_files = array();
        $manifest_exists = false;

        if ($res === TRUE) {
            // extract it to the path we determined above

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $file = $zip->statIndex($i);

                $item_name = $file['name'];
                $item_ext = pathinfo("{$item_name}", PATHINFO_EXTENSION);

                if ($item_name === 'imsmanifest.xml') $manifest_exists = true;

                if (!in_array($item_ext, $allowed_extensions)) $inappropriate_files[] = $item_name;

            }


            if (!empty($inappropriate_files)) {
                $inappropriate_files = "<ul><li>" . implode("</li><li>", $inappropriate_files) . "</li></ul>";

                unlink($archive);

                return array(
                    'error' => sprintf(esc_html__('Unacceptable files in package: %s', 'masterstudy-lms-learning-management-system'), $inappropriate_files)
                );
            }

            if (!$manifest_exists) {

                unlink($archive);

                return array(
                    'error' => sprintf(esc_html__('SCORM Package should contain file lmsmanifest.xml', 'masterstudy-lms-learning-management-system'), $inappropriate_files)
                );
            }

            $zip->extractTo("{$upload_dir}/{$archive_name}");
            $zip->close();
            unlink($archive);

            $r['path'] = "{$upload_dir}/{$archive_name}";
            $r['url'] = "{$upload_url}/{$archive_name}";

        } else {
            $r['error'] = esc_html__('Could not extract zip contents. Try another SCORM package', 'masterstudy-lms-learning-management-system');
        }

        return $r;
    }

    function redirect_to_scorm($post_id, $item_id)
    {

        if (self::is_scorm_course($post_id)) {

            /*redirect to 0 lesson*/
            if ($item_id !== '0') {

                $scorm_url = str_replace('stm_lms_scorm_lesson_id', '0', STM_LMS_Lesson::get_lesson_url($post_id, 'stm_lms_scorm_lesson_id'));

                wp_redirect($scorm_url);
            }

            STM_LMS_Templates::show_lms_template('lesson/scorm', compact('post_id', 'item_id'));
        }

    }

    static function get_scorm_meta($post_id)
    {
        return json_decode(get_post_meta($post_id, 'scorm_package', true), true);
    }

    static function is_scorm_course($post_id)
    {
        $scorm_package = get_post_meta($post_id, 'scorm_package', true);

        if (empty($scorm_package)) return false;

        $scorm_package = json_decode($scorm_package, true);

        return (empty($scorm_package['error']) && !empty($scorm_package['path']) && !empty($scorm_package['url']));
    }

    static function get_iframe_url($course_id)
    {

        $scorm = self::get_scorm_meta($course_id);

        $manifest = simplexml_load_file(self::get_course_scorm_manifest($course_id, $scorm));

        if (!empty($manifest)
            and !empty($manifest->resources)
            and !empty($manifest->resources->resource)
            and !empty($manifest->resources->resource->attributes())
        ) {
            $atts = $manifest->resources->resource->attributes();
            if (!empty($atts->href)) return (string)"{$scorm['url']}/" . $atts->href;
        }

        return false;
    }

    static function get_course_scorm_manifest($post_id, $scorm)
    {
        $path = $scorm['path'];
        $manifest_path = "{$path}/imsmanifest.xml";

        return (file_exists($manifest_path)) ? $manifest_path : false;
    }

    function add_scorm_package_uploader()
    {
        $field_data = self::package_data();
        ?>

        <wpcfto_file :field_label="'<?php echo esc_attr($field_data['label']); ?>'"
                     :field_name="'scorm_package'"
                     :field_id="'section_curriculum-scorm_package'"
                     :field_value="fields['scorm_package']"
                     :field_data='<?php echo json_encode($field_data); ?>'
                     @wpcfto-get-value="fields['scorm_package'] = $event">
        </wpcfto_file>

        <p class="description" v-html="'<?php echo wp_kses_post($field_data['description']); ?>'"></p>

        <hr/>

    <?php }

    function curriculum_atts()
    {
        echo 'v-if="!fields[\'scorm_package\']"';
    }

    function required_fields($required_fields)
    {

        if (!empty($required_fields['curriculum']) and isset($_POST['scorm_package'])) {
            $scorm_package = json_decode(wp_unslash($_POST['scorm_package']), true);
            if (!empty($scorm_package) and !empty($scorm_package['path']) and !empty($scorm_package['url'])) {
                unset($required_fields['curriculum']);
            }
        }

        return $required_fields;
    }

    function frontend_course_add_package($data, $course_id)
    {

        if (isset($data['scorm_package'])) {
            $scorm_package = json_decode(wp_unslash($data['scorm_package']), true);
            if (!empty($scorm_package) and !empty($scorm_package['path']) and !empty($scorm_package['url'])) {

                $scorm_package = array(
                    'error' => '',
                    'path' => sanitize_text_field($scorm_package['path']),
                    'url' => sanitize_text_field($scorm_package['url']),
                );

                update_post_meta($course_id, 'scorm_package', json_encode($scorm_package));

            }
        }

    }

}