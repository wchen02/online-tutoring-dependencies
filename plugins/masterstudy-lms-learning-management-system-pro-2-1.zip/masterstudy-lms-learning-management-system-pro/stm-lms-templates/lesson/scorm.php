<?php
/**
 * @var $post_id
 * @var $item_id
 */

stm_lms_register_style('scorm/scorm');
stm_lms_register_script('scorm/pipwerks');
stm_lms_register_script('scorm/scorm');
$scorm_url = STM_LMS_Scorm_Packages::get_iframe_url($post_id);

if(!empty($scorm_url)): ?>
    <div class="stm-lms-course__overlay"></div>

    <div class="stm-lms-wrapper scorm">
        <iframe src="<?php echo esc_url($scorm_url); ?>"></iframe>
    </div>
<?php else : ?>

<?php endif;