<?php STM_LMS_Templates::show_lms_template('manage_course/forms/js/wizard'); ?>

<stm-wizard v-bind:fields="fields"></stm-wizard>